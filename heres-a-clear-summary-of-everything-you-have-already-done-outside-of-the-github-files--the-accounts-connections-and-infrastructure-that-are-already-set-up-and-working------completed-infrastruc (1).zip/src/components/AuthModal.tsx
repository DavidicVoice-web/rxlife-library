import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Lock, User, GraduationCap, Loader2, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  mode: 'login' | 'signup';
  onClose: () => void;
  onSwitchMode: (mode: 'login' | 'signup') => void;
}

const academicLevels = [
  'Pharmacy Student - Year 1',
  'Pharmacy Student - Year 2',
  'Pharmacy Student - Year 3',
  'Pharmacy Student - Year 4',
  'Pharmacy Student - Year 5',
  'Pharmacy Graduate',
  'Licensed Pharmacist',
  'Pharmacy Technician',
  'Researcher',
  'Educator',
  'Other',
];

export default function AuthModal({ isOpen, mode, onClose, onSwitchMode }: AuthModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('Rx');
  const [academicLevel, setAcademicLevel] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const { login, signup } = useAuth();

  const validateUsername = (value: string) => {
    if (!value.startsWith('Rx')) {
      return 'Username must start with "Rx"';
    }
    if (value.length < 4) {
      return 'Username must be at least 4 characters';
    }
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (mode === 'signup') {
      const usernameError = validateUsername(username);
      if (usernameError) {
        setError(usernameError);
        return;
      }
      if (!academicLevel) {
        setError('Please select your academic level');
        return;
      }
    }

    setIsLoading(true);

    try {
      if (mode === 'login') {
        await login(email, password);
        onClose();
      } else {
        await signup(email, password, username, academicLevel);
        setSuccess('Account created! Please check your email to verify your account.');
        setTimeout(() => {
          onSwitchMode('login');
          setSuccess('');
        }, 3000);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUsernameChange = (value: string) => {
    // Ensure username always starts with Rx
    if (!value.startsWith('Rx')) {
      value = 'Rx' + value.replace(/^Rx?/i, '');
    }
    setUsername(value);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 25 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md backdrop-blur-xl bg-white/90 dark:bg-slate-900/90 rounded-3xl shadow-2xl border border-white/30 overflow-hidden"
          >
            {/* Header */}
            <div className="relative px-6 pt-6 pb-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white">
              <button
                onClick={onClose}
                className="absolute right-4 top-4 p-2 rounded-full hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                  <span className="text-xl font-bold">Rx</span>
                </div>
                <div>
                  <h2 className="text-xl font-bold">
                    {mode === 'login' ? 'Welcome Back' : 'Join RxLife'}
                  </h2>
                  <p className="text-white/80 text-sm">
                    {mode === 'login' ? 'Sign in to continue' : 'Create your pharmacy profile'}
                  </p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm"
                >
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </motion.div>
              )}

              {success && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 p-3 bg-green-50 border border-green-100 rounded-xl text-green-600 text-sm"
                >
                  <Check className="w-4 h-4 shrink-0" />
                  {success}
                </motion.div>
              )}

              <div className="space-y-3">
                {/* Email */}
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    placeholder="Email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full pl-11 pr-4 py-3 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700"
                  />
                </div>

                {/* Username (signup only) */}
                {mode === 'signup' && (
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Username (e.g., RxPharm_John)"
                      value={username}
                      onChange={(e) => handleUsernameChange(e.target.value)}
                      required
                      className="w-full pl-11 pr-4 py-3 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">
                      Must start with Rx
                    </span>
                  </div>
                )}

                {/* Academic Level (signup only) */}
                {mode === 'signup' && (
                  <div className="relative">
                    <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <select
                      value={academicLevel}
                      onChange={(e) => setAcademicLevel(e.target.value)}
                      required
                      className="w-full pl-11 pr-4 py-3 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 appearance-none cursor-pointer"
                    >
                      <option value="">Select academic level</option>
                      {academicLevels.map((level) => (
                        <option key={level} value={level}>{level}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Password */}
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-11 pr-4 py-3 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700"
                  />
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl font-medium shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : mode === 'login' ? (
                  'Sign In'
                ) : (
                  'Create Account'
                )}
              </motion.button>

              <div className="text-center text-sm text-slate-500">
                {mode === 'login' ? (
                  <>
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => onSwitchMode('signup')}
                      className="text-teal-600 font-medium hover:underline"
                    >
                      Sign up
                    </button>
                  </>
                ) : (
                  <>
                    Already have an account?{' '}
                    <button
                      type="button"
                      onClick={() => onSwitchMode('login')}
                      className="text-teal-600 font-medium hover:underline"
                    >
                      Sign in
                    </button>
                  </>
                )}
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
