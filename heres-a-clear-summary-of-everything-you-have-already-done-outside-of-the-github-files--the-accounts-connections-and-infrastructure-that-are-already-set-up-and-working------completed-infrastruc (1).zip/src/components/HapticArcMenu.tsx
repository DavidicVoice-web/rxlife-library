import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Home,
  BookOpen,
  Video,
  Image,
  BookText,
  GraduationCap,
  Upload,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const menuItems = [
  { icon: Home, label: 'Home', path: '/', rotation: -12 },
  { icon: BookOpen, label: 'Books', path: '/books', rotation: -8 },
  { icon: Video, label: 'Videos', path: '/videos', rotation: -4 },
  { icon: Image, label: 'Images', path: '/images', rotation: 0 },
  { icon: BookText, label: 'Dictionary', path: '/dictionary', rotation: 4 },
  { icon: GraduationCap, label: 'Courses', path: '/courses', rotation: 8 },
  { icon: Upload, label: 'Upload', path: '/upload', rotation: 10, requiresAuth: true },
  { icon: User, label: 'Profile', path: '/profile', rotation: 12, requiresAuth: true },
];

export default function HapticArcMenu() {
  const [isVisible, setIsVisible] = useState(false);
  const [touchStartY, setTouchStartY] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated } = useAuth();

  // Filter menu items based on auth
  const visibleMenuItems = menuItems.filter(
    (item) => !item.requiresAuth || isAuthenticated
  );

  // Touch handlers for mobile swipe
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0];
      if (touch.clientY > window.innerHeight - 100) {
        setTouchStartY(touch.clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (touchStartY === null) return;
      const touch = e.touches[0];
      const diff = touchStartY - touch.clientY;
      
      if (diff > 50) {
        setIsVisible(true);
        setTouchStartY(null);
      } else if (diff < -50 && isVisible) {
        setIsVisible(false);
        setTouchStartY(null);
      }
    };

    const handleTouchEnd = () => {
      setTouchStartY(null);
    };

    document.addEventListener('touchstart', handleTouchStart);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleTouchEnd);

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [touchStartY, isVisible]);

  // Mouse handler for desktop
  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;

    const handleMouseMove = (e: MouseEvent) => {
      const threshold = 80;
      const isNearBottom = e.clientY > window.innerHeight - threshold;
      
      if (isNearBottom) {
        clearTimeout(timeout);
        setIsVisible(true);
      } else if (isVisible) {
        timeout = setTimeout(() => {
          setIsVisible(false);
        }, 500);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      clearTimeout(timeout);
    };
  }, [isVisible]);

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsVisible(false);
      }
    };

    if (isVisible) {
      document.addEventListener('click', handleClickOutside);
    }

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isVisible]);

  const handleNavigate = (path: string) => {
    navigate(path);
    setIsVisible(false);
  };

  return (
    <>
      {/* Swipe indicator for mobile */}
      <motion.div
        className="fixed bottom-2 left-1/2 -translate-x-1/2 md:hidden z-40"
        initial={{ opacity: 0 }}
        animate={{ opacity: isVisible ? 0 : 0.5 }}
        transition={{ duration: 0.3 }}
      >
        <div className="w-12 h-1 bg-white/50 rounded-full" />
        <p className="text-white/40 text-xs text-center mt-1">Swipe up</p>
      </motion.div>

      {/* Menu */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            ref={menuRef}
            initial={{ y: '120%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '120%', opacity: 0 }}
            transition={{ 
              type: 'spring', 
              stiffness: 300, 
              damping: 30,
              mass: 0.8
            }}
            className="fixed bottom-4 left-4 right-4 md:left-1/2 md:-translate-x-1/2 md:max-w-xl z-50"
          >
            <div className="relative backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 rounded-[40px] shadow-2xl shadow-teal-900/20 border border-white/30 px-3 py-3">
              {/* Glow effect */}
              <div className="absolute inset-0 rounded-[40px] bg-gradient-to-r from-teal-400/10 via-blue-400/10 to-teal-400/10 blur-xl -z-10" />
              
              <div className="flex items-center justify-around">
                {visibleMenuItems.map((item, index) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <motion.button
                      key={item.path}
                      onClick={() => handleNavigate(item.path)}
                      initial={{ rotate: item.rotation * 2, scale: 0.5, opacity: 0 }}
                      animate={{ rotate: 0, scale: 1, opacity: 1 }}
                      transition={{ 
                        delay: index * 0.05,
                        type: 'spring',
                        stiffness: 400,
                        damping: 20
                      }}
                      whileHover={{ scale: 1.15 }}
                      whileTap={{ scale: 0.95 }}
                      className={`relative flex flex-col items-center gap-0.5 px-2 py-2 rounded-2xl transition-colors duration-200
                        ${isActive 
                          ? 'text-teal-600 bg-teal-100/80' 
                          : 'text-slate-600 hover:text-teal-500 hover:bg-teal-50/50'
                        }`}
                    >
                      <motion.div
                        initial={{ rotate: item.rotation }}
                        animate={{ rotate: isActive ? 0 : item.rotation / 2 }}
                        transition={{ duration: 0.3 }}
                      >
                        <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[2]'}`} />
                      </motion.div>
                      <span className="text-[10px] font-medium">{item.label}</span>
                      
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="absolute -bottom-1 w-1 h-1 bg-teal-500 rounded-full"
                        />
                      )}
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
