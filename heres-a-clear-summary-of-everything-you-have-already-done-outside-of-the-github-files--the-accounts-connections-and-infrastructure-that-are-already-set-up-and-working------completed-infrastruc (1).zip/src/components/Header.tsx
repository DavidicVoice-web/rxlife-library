import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Menu, X, LogIn, User, LogOut, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';

interface HeaderProps {
  onSearch: (query: string, filter: string) => void;
}

const filters = [
  { value: 'all', label: 'All' },
  { value: 'books', label: 'Books' },
  { value: 'videos', label: 'Videos' },
  { value: 'images', label: 'Images' },
  { value: 'dictionary', label: 'Dictionary' },
  { value: 'courses', label: 'Courses' },
];

export default function Header({ onSearch }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | null>(null);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  
  const { isAuthenticated, profile, logout } = useAuth();
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery, selectedFilter);
      navigate(`/search?q=${encodeURIComponent(searchQuery)}&filter=${selectedFilter}`);
    }
  };

  const handleLogout = async () => {
    await logout();
    setIsUserMenuOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-40">
        <div className="mx-4 mt-4">
          <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 rounded-2xl shadow-lg shadow-slate-900/5 border border-white/30"
          >
            <div className="px-4 py-3">
              <div className="flex items-center justify-between gap-4">
                {/* Logo */}
                <motion.button
                  onClick={() => navigate('/')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-2 shrink-0"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center shadow-lg shadow-teal-500/30">
                    <span className="text-white font-bold text-lg">Rx</span>
                  </div>
                  <div className="hidden sm:block">
                    <h1 className="text-lg font-bold bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">
                      RxLife
                    </h1>
                    <p className="text-[10px] text-slate-500 -mt-0.5">Network Library</p>
                  </div>
                </motion.button>

                {/* Search Bar - Desktop */}
                <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search pharmacy resources..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-100/80 dark:bg-slate-800/50 rounded-xl border border-slate-200/50 dark:border-slate-700/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 dark:text-slate-200 text-sm placeholder-slate-400"
                    />
                  </div>
                  <select
                    value={selectedFilter}
                    onChange={(e) => setSelectedFilter(e.target.value)}
                    className="px-3 py-2.5 bg-slate-100/80 dark:bg-slate-800/50 rounded-xl border border-slate-200/50 dark:border-slate-700/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-600 dark:text-slate-300 text-sm cursor-pointer"
                  >
                    {filters.map((f) => (
                      <option key={f.value} value={f.value}>{f.label}</option>
                    ))}
                  </select>
                </form>

                {/* User Area */}
                <div className="flex items-center gap-2">
                  {/* Admin Link */}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigate('/admin')}
                    className="hidden sm:flex p-2 rounded-xl text-slate-500 hover:text-teal-600 hover:bg-teal-50/50 transition-colors"
                    title="Admin Panel"
                  >
                    <Shield className="w-5 h-5" />
                  </motion.button>

                  {isAuthenticated ? (
                    <div className="relative">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-blue-500 text-white text-sm font-medium shadow-lg shadow-teal-500/25"
                      >
                        <User className="w-4 h-4" />
                        <span className="hidden sm:block max-w-[100px] truncate">
                          {profile?.username || 'User'}
                        </span>
                      </motion.button>
                      
                      {isUserMenuOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="absolute right-0 top-full mt-2 w-48 backdrop-blur-xl bg-white/90 dark:bg-slate-800/90 rounded-xl shadow-xl border border-white/30 overflow-hidden"
                        >
                          <button
                            onClick={() => { navigate('/profile'); setIsUserMenuOpen(false); }}
                            className="w-full px-4 py-3 text-left text-sm text-slate-700 hover:bg-teal-50 flex items-center gap-2"
                          >
                            <User className="w-4 h-4" />
                            Profile
                          </button>
                          <button
                            onClick={handleLogout}
                            className="w-full px-4 py-3 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 border-t border-slate-100"
                          >
                            <LogOut className="w-4 h-4" />
                            Logout
                          </button>
                        </motion.div>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setAuthModalMode('login')}
                        className="px-4 py-2 rounded-xl text-slate-600 hover:text-teal-600 hover:bg-teal-50/50 text-sm font-medium transition-colors"
                      >
                        Login
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setAuthModalMode('signup')}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-blue-500 text-white text-sm font-medium shadow-lg shadow-teal-500/25 flex items-center gap-2"
                      >
                        <LogIn className="w-4 h-4" />
                        <span className="hidden sm:block">Sign Up</span>
                      </motion.button>
                    </div>
                  )}

                  {/* Mobile Menu Toggle */}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    className="md:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100"
                  >
                    {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </motion.button>
                </div>
              </div>

              {/* Mobile Search */}
              {isMobileMenuOpen && (
                <motion.form
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  onSubmit={handleSearch}
                  className="md:hidden mt-4 pt-4 border-t border-slate-200/50"
                >
                  <div className="flex flex-col gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search resources..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 text-sm"
                      />
                    </div>
                    <div className="flex gap-2">
                      <select
                        value={selectedFilter}
                        onChange={(e) => setSelectedFilter(e.target.value)}
                        className="flex-1 px-3 py-2.5 bg-slate-100/80 rounded-xl border border-slate-200/50 focus:outline-none text-slate-600 text-sm"
                      >
                        {filters.map((f) => (
                          <option key={f.value} value={f.value}>{f.label}</option>
                        ))}
                      </select>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit"
                        className="px-6 py-2.5 bg-gradient-to-r from-teal-500 to-blue-500 text-white rounded-xl text-sm font-medium"
                      >
                        Search
                      </motion.button>
                    </div>
                  </div>
                </motion.form>
              )}
            </div>
          </motion.div>
        </div>
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalMode !== null}
        mode={authModalMode || 'login'}
        onClose={() => setAuthModalMode(null)}
        onSwitchMode={(mode: 'login' | 'signup') => setAuthModalMode(mode)}
      />
    </>
  );
}
