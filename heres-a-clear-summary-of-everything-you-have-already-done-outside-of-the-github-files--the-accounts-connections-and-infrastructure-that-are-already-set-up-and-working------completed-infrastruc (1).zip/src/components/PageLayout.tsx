import { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface PageLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  gradient?: string;
}

export default function PageLayout({ 
  children, 
  title, 
  subtitle, 
  icon,
  gradient = 'from-teal-500 to-blue-600' 
}: PageLayoutProps) {
  return (
    <div className="min-h-screen pt-24 pb-32 px-4">
      <div className="max-w-7xl mx-auto">
        {title && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-4 mb-2">
              {icon && (
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${gradient} flex items-center justify-center shadow-lg`}>
                  <span className="text-white">{icon}</span>
                </div>
              )}
              <div>
                <h1 className={`text-3xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
                  {title}
                </h1>
                {subtitle && (
                  <p className="text-slate-600 dark:text-slate-400 mt-1">
                    {subtitle}
                  </p>
                )}
              </div>
            </div>
          </motion.div>
        )}
        {children}
      </div>
    </div>
  );
}
