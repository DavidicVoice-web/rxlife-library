import { motion } from 'framer-motion';
import { Download, ExternalLink, BookOpen, Video, Image, BookText, GraduationCap } from 'lucide-react';

interface ResourceCardProps {
  type: 'book' | 'video' | 'image' | 'dictionary' | 'course';
  title: string;
  description?: string;
  subtitle?: string;
  fileUrl?: string;
  thumbnailUrl?: string;
  progress?: number;
  onClick?: () => void;
  onDownload?: () => void;
}

const typeConfig = {
  book: { icon: BookOpen, color: 'from-blue-500 to-indigo-500', bg: 'bg-blue-50' },
  video: { icon: Video, color: 'from-red-500 to-pink-500', bg: 'bg-red-50' },
  image: { icon: Image, color: 'from-green-500 to-emerald-500', bg: 'bg-green-50' },
  dictionary: { icon: BookText, color: 'from-purple-500 to-violet-500', bg: 'bg-purple-50' },
  course: { icon: GraduationCap, color: 'from-orange-500 to-amber-500', bg: 'bg-orange-50' },
};

export default function ResourceCard({
  type,
  title,
  description,
  subtitle,
  fileUrl,
  thumbnailUrl,
  progress,
  onClick,
  onDownload,
}: ResourceCardProps) {
  const config = typeConfig[type];
  const Icon = config.icon;

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.01 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      className="group relative backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 rounded-2xl shadow-lg shadow-slate-900/5 border border-white/30 overflow-hidden cursor-pointer"
      onClick={onClick}
    >
      {/* Glow effect on hover */}
      <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r ${config.color} blur-xl -z-10`} />
      
      {/* Thumbnail or Gradient Header */}
      {thumbnailUrl ? (
        <div className="relative h-40 overflow-hidden">
          <img
            src={thumbnailUrl}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>
      ) : (
        <div className={`relative h-24 bg-gradient-to-r ${config.color} flex items-center justify-center`}>
          <Icon className="w-10 h-10 text-white/80" />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCA0LTRzNCAyIDQgNC0yIDQtNCA0LTQtMi00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
        </div>
      )}

      {/* Content */}
      <div className="p-4">
        {/* Type Badge */}
        <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 ${config.bg} rounded-lg mb-3`}>
          <Icon className={`w-3.5 h-3.5 bg-gradient-to-r ${config.color} bg-clip-text text-transparent`} />
          <span className={`text-xs font-medium capitalize bg-gradient-to-r ${config.color} bg-clip-text text-transparent`}>
            {type}
          </span>
        </div>

        {/* Title */}
        <h3 className="font-semibold text-slate-800 dark:text-white line-clamp-2 mb-1 group-hover:text-teal-600 transition-colors">
          {title}
        </h3>

        {/* Subtitle */}
        {subtitle && (
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">{subtitle}</p>
        )}

        {/* Description */}
        {description && (
          <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
            {description}
          </p>
        )}

        {/* Progress Bar (for courses) */}
        {typeof progress === 'number' && (
          <div className="mb-3">
            <div className="flex justify-between text-xs text-slate-500 mb-1">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className={`h-full bg-gradient-to-r ${config.color} rounded-full`}
              />
            </div>
          </div>
        )}

        {/* Actions */}
        {(fileUrl || onDownload) && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/50">
            {fileUrl && (
              <motion.a
                href={fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gradient-to-r from-teal-500 to-blue-500 text-white text-sm font-medium rounded-xl shadow-lg shadow-teal-500/20"
              >
                <Download className="w-4 h-4" />
                Download
              </motion.a>
            )}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => { e.stopPropagation(); }}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
            >
              <ExternalLink className="w-4 h-4" />
            </motion.button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
