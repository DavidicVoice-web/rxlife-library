// Mock data for demo purposes when backend is not available

export const mockBooks = [
  {
    id: 1,
    title: "Goodman & Gilman's: The Pharmacological Basis of Therapeutics",
    author: "Laurence Brunton",
    description: "The gold standard in pharmacology textbooks, covering basic principles and clinical applications.",
    file_url: "#",
    thumbnail_url: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&h=300&fit=crop",
    created_at: "2024-01-15T10:00:00Z"
  },
  {
    id: 2,
    title: "Martindale: The Complete Drug Reference",
    author: "Royal Pharmaceutical Society",
    description: "Comprehensive reference on drugs and medicines used throughout the world.",
    file_url: "#",
    thumbnail_url: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=300&fit=crop",
    created_at: "2024-01-10T10:00:00Z"
  },
  {
    id: 3,
    title: "Clinical Pharmacokinetics",
    author: "Malcolm Rowland",
    description: "Essential concepts of pharmacokinetics for clinical practice and drug development.",
    file_url: "#",
    thumbnail_url: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400&h=300&fit=crop",
    created_at: "2024-01-05T10:00:00Z"
  },
  {
    id: 4,
    title: "Remington: The Science and Practice of Pharmacy",
    author: "David B. Troy",
    description: "The most comprehensive pharmacy textbook covering all aspects of pharmaceutical sciences.",
    file_url: "#",
    created_at: "2024-01-01T10:00:00Z"
  },
];

export const mockVideos = [
  {
    id: 1,
    title: "Drug-Drug Interactions: A Clinical Perspective",
    duration: "45:30",
    description: "Learn about common drug interactions and how to prevent adverse effects in clinical practice.",
    file_url: "#",
    thumbnail_url: "https://images.unsplash.com/photo-1585435557343-3b092031a831?w=400&h=300&fit=crop",
    created_at: "2024-02-01T10:00:00Z"
  },
  {
    id: 2,
    title: "Pharmacology of Diabetes Medications",
    duration: "32:15",
    description: "Comprehensive review of antidiabetic drugs including insulin, metformin, and newer agents.",
    file_url: "#",
    thumbnail_url: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400&h=300&fit=crop",
    created_at: "2024-01-28T10:00:00Z"
  },
  {
    id: 3,
    title: "Antibiotic Stewardship in Practice",
    duration: "28:45",
    description: "Best practices for antimicrobial stewardship to combat antibiotic resistance.",
    file_url: "#",
    created_at: "2024-01-20T10:00:00Z"
  },
];

export const mockImages = [
  {
    id: 1,
    title: "Drug Metabolism Pathways",
    source: "PharmacologyEducation.org",
    description: "Visual diagram showing Phase I and Phase II metabolic reactions.",
    file_url: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&h=600&fit=crop",
    created_at: "2024-02-05T10:00:00Z"
  },
  {
    id: 2,
    title: "Cardiac Drug Sites of Action",
    source: "Medical Illustrations Inc.",
    description: "Illustration showing where different cardiac medications act on the heart.",
    file_url: "https://images.unsplash.com/photo-1628595351029-c2bf17511435?w=800&h=600&fit=crop",
    created_at: "2024-02-03T10:00:00Z"
  },
  {
    id: 3,
    title: "Neurotransmitter Receptors Chart",
    source: "NeuroPharma Education",
    description: "Comprehensive chart of neurotransmitter receptors and their ligands.",
    file_url: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=600&fit=crop",
    created_at: "2024-02-01T10:00:00Z"
  },
];

export const mockDictionary = [
  { id: 1, term: "Agonist", definition: "A substance that binds to a receptor and activates it, producing a biological response." },
  { id: 2, term: "Antagonist", definition: "A substance that blocks or dampens a biological response by binding to and blocking a receptor." },
  { id: 3, term: "Bioavailability", definition: "The proportion of a drug that enters the systemic circulation and is available to produce a pharmacological effect." },
  { id: 4, term: "Clearance", definition: "The volume of plasma from which a drug is completely removed per unit time." },
  { id: 5, term: "Distribution Volume", definition: "A theoretical volume that would be necessary to contain the total amount of drug at the same concentration as in plasma." },
  { id: 6, term: "Efficacy", definition: "The maximum response achievable from a drug, regardless of dose." },
  { id: 7, term: "First-pass Effect", definition: "The phenomenon where the concentration of a drug is greatly reduced before it reaches systemic circulation." },
  { id: 8, term: "Half-life", definition: "The time required for the plasma concentration of a drug to decrease by 50%." },
  { id: 9, term: "Idiosyncrasy", definition: "An unusual, unexpected response to a drug that occurs in some individuals." },
  { id: 10, term: "Loading Dose", definition: "An initial higher dose given to rapidly achieve therapeutic plasma concentration." },
  { id: 11, term: "Metabolism", definition: "The chemical alteration of a drug by the body, primarily in the liver." },
  { id: 12, term: "Pharmacodynamics", definition: "The study of the biochemical and physiological effects of drugs and their mechanisms of action." },
  { id: 13, term: "Pharmacokinetics", definition: "The study of how the body affects a drug, including absorption, distribution, metabolism, and excretion." },
  { id: 14, term: "Prodrug", definition: "A pharmacologically inactive compound that is converted to an active drug in the body." },
  { id: 15, term: "Steady State", definition: "The condition where drug intake equals drug elimination, resulting in stable plasma concentrations." },
  { id: 16, term: "Therapeutic Index", definition: "The ratio of the toxic dose to the therapeutic dose, indicating the relative safety of a drug." },
  { id: 17, term: "Tolerance", definition: "A decrease in the response to a drug after repeated administration." },
  { id: 18, term: "Withdrawal", definition: "Symptoms that occur when a drug is discontinued after prolonged use." },
];

export const mockCourses = [
  {
    id: 1,
    title: "Fundamentals of Pharmacology",
    description: "A comprehensive introduction to pharmacology covering drug actions, interactions, and clinical applications.",
    lessons: [
      "Introduction to Pharmacology",
      "Drug-Receptor Interactions",
      "Pharmacokinetics Basics",
      "Drug Absorption and Distribution",
      "Drug Metabolism and Excretion",
      "Dose-Response Relationships",
      "Drug Interactions",
      "Adverse Drug Reactions",
    ],
    created_at: "2024-01-01T10:00:00Z"
  },
  {
    id: 2,
    title: "Clinical Pharmacy Practice",
    description: "Learn essential clinical pharmacy skills including medication therapy management and patient counseling.",
    lessons: [
      "Role of the Clinical Pharmacist",
      "Patient Assessment Skills",
      "Medication Therapy Management",
      "Drug Information Resources",
      "Patient Counseling Techniques",
      "Medication Reconciliation",
      "Therapeutic Monitoring",
    ],
    created_at: "2024-01-15T10:00:00Z"
  },
  {
    id: 3,
    title: "Cardiovascular Pharmacology",
    description: "Deep dive into cardiovascular medications including antihypertensives, antiarrhythmics, and anticoagulants.",
    lessons: [
      "Cardiovascular System Overview",
      "Antihypertensive Drugs",
      "Beta Blockers and Calcium Channel Blockers",
      "Diuretics in Practice",
      "Antiarrhythmic Medications",
      "Anticoagulants and Antiplatelets",
      "Heart Failure Management",
    ],
    created_at: "2024-02-01T10:00:00Z"
  },
];
