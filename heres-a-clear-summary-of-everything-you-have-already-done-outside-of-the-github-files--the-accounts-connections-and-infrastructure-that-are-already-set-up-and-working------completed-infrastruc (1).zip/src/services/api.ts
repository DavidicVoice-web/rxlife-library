// API Service for RxLife Network Library
// Connects to Vercel serverless functions
// Falls back to mock data when backend is not available

import { mockBooks, mockVideos, mockImages, mockDictionary, mockCourses } from './mockData';

const API_BASE = '/api';
const USE_MOCK = true; // Set to false when backend is connected

// Helper to get auth token
const getToken = (): string | null => {
  return localStorage.getItem('rxlife_token');
};

// Generic fetch wrapper
async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {},
  mockData?: T
): Promise<T> {
  // Return mock data if enabled and available
  if (USE_MOCK && mockData !== undefined) {
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockData), 300); // Simulate network delay
    });
  }

  const token = getToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Request failed' }));
    throw new Error(error.message || `HTTP error ${response.status}`);
  }

  return response.json();
}

// Auth endpoints
export const auth = {
  signup: async (data: { email: string; password: string; username: string; academic_level: string }) => {
    if (USE_MOCK) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (!data.username.startsWith('Rx')) {
            reject(new Error('Username must start with Rx'));
            return;
          }
          resolve({ success: true, message: 'Account created' });
        }, 500);
      });
    }
    return apiFetch('/auth/signup', { method: 'POST', body: JSON.stringify(data) });
  },
  
  login: async (data: { email: string; password: string }) => {
    if (USE_MOCK) {
      return new Promise<{ token: string; user: any }>((resolve, reject) => {
        setTimeout(() => {
          // Demo login - accept any email with password "demo123"
          if (data.password === 'demo123') {
            const token = btoa(JSON.stringify({ email: data.email, exp: Date.now() + 86400000 }));
            localStorage.setItem('rxlife_token', token);
            resolve({
              token,
              user: {
                id: '1',
                email: data.email,
              },
            });
          } else {
            reject(new Error('Invalid credentials. Use password "demo123" for demo.'));
          }
        }, 500);
      });
    }
    return apiFetch<{ token: string; user: any }>('/auth/login', { method: 'POST', body: JSON.stringify(data) });
  },
  
  logout: async () => {
    if (USE_MOCK) {
      localStorage.removeItem('rxlife_token');
      return Promise.resolve();
    }
    return apiFetch('/auth/logout', { method: 'POST' });
  },
  
  resetPassword: async (email: string) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true }), 500);
      });
    }
    return apiFetch('/auth/reset-password', { method: 'POST', body: JSON.stringify({ email }) });
  },
  
  getUser: async () => {
    if (USE_MOCK) {
      const token = getToken();
      if (!token) throw new Error('Not authenticated');
      
      try {
        const data = JSON.parse(atob(token));
        return {
          user: { id: '1', email: data.email },
          profile: {
            id: '1',
            username: 'Rx' + data.email.split('@')[0],
            academic_level: 'Pharmacy Student - Year 3',
            created_at: new Date().toISOString(),
          },
        };
      } catch {
        throw new Error('Invalid token');
      }
    }
    return apiFetch<{ user: any; profile: any }>('/auth/user');
  },
};

// Resource endpoints
export const resources = {
  getBooks: () => apiFetch<any[]>('/books', {}, mockBooks),
  getVideos: () => apiFetch<any[]>('/videos', {}, mockVideos),
  getImages: () => apiFetch<any[]>('/images', {}, mockImages),
  getDictionary: () => apiFetch<any[]>('/dictionary', {}, mockDictionary),
  getCourses: () => apiFetch<any[]>('/courses', {}, mockCourses),
  
  search: async (query: string, filter: string = 'all') => {
    if (USE_MOCK) {
      const q = query.toLowerCase();
      let results: any[] = [];
      
      if (filter === 'all' || filter === 'books') {
        results = results.concat(
          mockBooks.filter((b) => 
            b.title.toLowerCase().includes(q) || 
            b.author?.toLowerCase().includes(q) ||
            b.description?.toLowerCase().includes(q)
          )
        );
      }
      if (filter === 'all' || filter === 'videos') {
        results = results.concat(
          mockVideos.filter((v) => 
            v.title.toLowerCase().includes(q) ||
            v.description?.toLowerCase().includes(q)
          )
        );
      }
      if (filter === 'all' || filter === 'images') {
        results = results.concat(
          mockImages.filter((i) => 
            i.title.toLowerCase().includes(q) ||
            i.description?.toLowerCase().includes(q)
          )
        );
      }
      if (filter === 'all' || filter === 'dictionary') {
        results = results.concat(
          mockDictionary.filter((d) => 
            d.term.toLowerCase().includes(q) ||
            d.definition.toLowerCase().includes(q)
          )
        );
      }
      if (filter === 'all' || filter === 'courses') {
        results = results.concat(
          mockCourses.filter((c) => 
            c.title.toLowerCase().includes(q) ||
            c.description?.toLowerCase().includes(q)
          )
        );
      }
      
      return new Promise<any[]>((resolve) => {
        setTimeout(() => resolve(results), 300);
      });
    }
    return apiFetch<any[]>(`/search?q=${encodeURIComponent(query)}&filter=${filter}`);
  },
};

// Upload endpoint
export const uploads = {
  submit: async (formData: FormData) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true, message: 'Upload submitted for review' }), 1000);
      });
    }
    
    const token = getToken();
    const headers: HeadersInit = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    
    const response = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      headers,
      body: formData,
    });
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Upload failed' }));
      throw new Error(error.message);
    }
    
    return response.json();
  },
};

// Request endpoint
export const requests = {
  submit: async (data: { user_name?: string; request_text: string }) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true, message: 'Request submitted' }), 500);
      });
    }
    return apiFetch('/request', { method: 'POST', body: JSON.stringify(data) });
  },
};

// Course progress endpoints
let mockProgress: Record<number, number[]> = {};

export const progress = {
  get: async () => {
    if (USE_MOCK) {
      return Object.entries(mockProgress).map(([course_id, completed_lessons]) => ({
        course_id: parseInt(course_id),
        completed_lessons,
        updated_at: new Date().toISOString(),
      }));
    }
    return apiFetch<any[]>('/courses/progress');
  },
  
  update: async (course_id: number, lesson_index: number, completed: boolean) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => {
          if (!mockProgress[course_id]) {
            mockProgress[course_id] = [];
          }
          
          if (completed) {
            if (!mockProgress[course_id].includes(lesson_index)) {
              mockProgress[course_id].push(lesson_index);
            }
          } else {
            mockProgress[course_id] = mockProgress[course_id].filter((i) => i !== lesson_index);
          }
          
          resolve({ success: true });
        }, 300);
      });
    }
    return apiFetch('/courses/progress', {
      method: 'POST',
      body: JSON.stringify({ course_id, lesson_index, completed }),
    });
  },
};

// Admin endpoints
export const admin = {
  login: async (password: string) => {
    if (USE_MOCK) {
      return new Promise<{ success: boolean }>((resolve, reject) => {
        setTimeout(() => {
          // Demo admin password
          if (password === 'admin123') {
            resolve({ success: true });
          } else {
            reject(new Error('Invalid admin password. Use "admin123" for demo.'));
          }
        }, 500);
      });
    }
    return apiFetch<{ success: boolean }>('/admin/login', {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
  },
  
  getPending: async () => {
    if (USE_MOCK) {
      return new Promise<any[]>((resolve) => {
        setTimeout(() => resolve([
          {
            id: 1,
            type: 'book',
            data: { title: 'Pharmacy Practice Guidelines 2024', description: 'Updated guidelines for community pharmacy' },
            submitted_by: 'RxJohnDoe@email.com',
            status: 'pending',
            created_at: new Date().toISOString(),
          },
          {
            id: 2,
            type: 'video',
            data: { title: 'Insulin Administration Tutorial', description: 'Step-by-step guide for patients' },
            submitted_by: 'RxJaneSmith@email.com',
            status: 'pending',
            created_at: new Date().toISOString(),
          },
        ]), 300);
      });
    }
    return apiFetch<any[]>('/admin/pending');
  },
  
  approvePending: async (id: number) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true }), 500);
      });
    }
    return apiFetch(`/admin/pending?id=${id}&action=approve`, { method: 'POST' });
  },
  
  rejectPending: async (id: number) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true }), 500);
      });
    }
    return apiFetch(`/admin/pending?id=${id}&action=reject`, { method: 'POST' });
  },
  
  getRequests: async () => {
    if (USE_MOCK) {
      return new Promise<any[]>((resolve) => {
        setTimeout(() => resolve([
          {
            id: 1,
            user_name: 'Sarah M.',
            request_text: 'Looking for Pharmacotherapy Casebook 11th edition by Joseph DiPiro',
            resolved: false,
            created_at: new Date(Date.now() - 86400000).toISOString(),
          },
          {
            id: 2,
            user_name: 'Alex K.',
            request_text: 'Need video tutorials on pharmaceutical calculations',
            resolved: true,
            created_at: new Date(Date.now() - 172800000).toISOString(),
          },
        ]), 300);
      });
    }
    return apiFetch<any[]>('/admin/requests');
  },
  
  resolveRequest: async (id: number) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true }), 500);
      });
    }
    return apiFetch(`/admin/requests?id=${id}`, { method: 'POST' });
  },
  
  deleteResource: async (type: string, id: number) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true }), 500);
      });
    }
    return apiFetch(`/admin/resources?type=${type}&id=${id}`, { method: 'DELETE' });
  },
  
  addResource: async (type: string, data: any) => {
    if (USE_MOCK) {
      return new Promise((resolve) => {
        setTimeout(() => resolve({ success: true, id: Date.now() }), 500);
      });
    }
    return apiFetch(`/${type}s`, { method: 'POST', body: JSON.stringify(data) });
  },
};
