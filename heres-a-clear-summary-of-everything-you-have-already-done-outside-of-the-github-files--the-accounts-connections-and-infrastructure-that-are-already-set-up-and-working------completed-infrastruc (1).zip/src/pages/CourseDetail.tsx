import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap, ArrowLeft, Check, Circle, Lock } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources, progress } from '../services/api';
import { Course } from '../types';
import { useAuth } from '../context/AuthContext';

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [course, setCourse] = useState<Course | null>(null);
  const [completedLessons, setCompletedLessons] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const courses = await resources.getCourses();
        const found = courses.find((c: Course) => c.id === Number(id));
        setCourse(found || null);

        if (isAuthenticated && found) {
          try {
            const progressData = await progress.get();
            const courseProgress = progressData.find(
              (p: any) => p.course_id === found.id
            );
            if (courseProgress) {
              setCompletedLessons(courseProgress.completed_lessons || []);
            }
          } catch (error) {
            console.error('Failed to fetch progress:', error);
          }
        }
      } catch (error) {
        console.error('Failed to fetch course:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCourse();
  }, [id, isAuthenticated]);

  const toggleLesson = async (lessonIndex: number) => {
    if (!isAuthenticated || !course) return;

    const isCompleted = completedLessons.includes(lessonIndex);
    setIsSaving(true);

    try {
      await progress.update(course.id, lessonIndex, !isCompleted);
      
      if (isCompleted) {
        setCompletedLessons(completedLessons.filter((i) => i !== lessonIndex));
      } else {
        setCompletedLessons([...completedLessons, lessonIndex]);
      }
    } catch (error) {
      console.error('Failed to update progress:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const progressPercent = course?.lessons?.length
    ? Math.round((completedLessons.length / course.lessons.length) * 100)
    : 0;

  if (isLoading) {
    return (
      <PageLayout>
        <LoadingSpinner text="Loading course..." />
      </PageLayout>
    );
  }

  if (!course) {
    return (
      <PageLayout>
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold text-slate-700 dark:text-white mb-4">
            Course not found
          </h2>
          <button
            onClick={() => navigate('/courses')}
            className="text-teal-600 hover:underline"
          >
            Back to courses
          </button>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => navigate('/courses')}
        className="flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-teal-600 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Courses
      </motion.button>

      {/* Course Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="backdrop-blur-xl bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-6 md:p-8 mb-8 text-white relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCA0LTRzNCAyIDQgNC0yIDQtNCA0LTQtMi00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30" />
        
        <div className="relative z-10">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{course.title}</h1>
              {course.description && (
                <p className="text-white/80">{course.description}</p>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-sm">
            <div>
              <span className="text-white/60">Lessons</span>
              <p className="font-semibold">{course.lessons?.length || 0}</p>
            </div>
            <div>
              <span className="text-white/60">Duration</span>
              <p className="font-semibold">~{(course.lessons?.length || 0) * 15} min</p>
            </div>
            {isAuthenticated && (
              <div>
                <span className="text-white/60">Completed</span>
                <p className="font-semibold">{completedLessons.length} / {course.lessons?.length || 0}</p>
              </div>
            )}
          </div>

          {isAuthenticated && (
            <div className="mt-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Progress</span>
                <span>{progressPercent}%</span>
              </div>
              <div className="h-3 bg-white/20 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 0.5 }}
                  className="h-full bg-white rounded-full"
                />
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Lessons List */}
      <div className="space-y-3">
        <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4">
          Course Content
        </h2>

        {course.lessons?.map((lesson, index) => {
          const isCompleted = completedLessons.includes(index);
          
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`backdrop-blur-xl rounded-xl border overflow-hidden transition-all ${
                isCompleted
                  ? 'bg-green-50/70 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                  : 'bg-white/70 dark:bg-slate-800/70 border-white/30'
              }`}
            >
              <div className="flex items-center gap-4 p-4">
                {isAuthenticated ? (
                  <button
                    onClick={() => toggleLesson(index)}
                    disabled={isSaving}
                    className={`shrink-0 w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-green-500 border-green-500 text-white'
                        : 'border-slate-300 dark:border-slate-600 hover:border-green-400'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-300" />
                    )}
                  </button>
                ) : (
                  <div className="shrink-0 w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                    <Lock className="w-4 h-4 text-slate-400" />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-500 dark:text-slate-400">
                    Lesson {index + 1}
                  </p>
                  <h3 className={`font-medium ${
                    isCompleted
                      ? 'text-green-700 dark:text-green-400'
                      : 'text-slate-800 dark:text-white'
                  }`}>
                    {lesson}
                  </h3>
                </div>

                {isCompleted && (
                  <span className="text-xs text-green-600 dark:text-green-400 font-medium px-2 py-1 bg-green-100 dark:bg-green-900/30 rounded-lg">
                    Completed
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}

        {!course.lessons?.length && (
          <div className="text-center py-8 text-slate-500">
            No lessons available for this course yet.
          </div>
        )}
      </div>

      {!isAuthenticated && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 p-6 backdrop-blur-xl bg-teal-50/70 dark:bg-teal-900/20 rounded-2xl border border-teal-200 dark:border-teal-800 text-center"
        >
          <Lock className="w-8 h-8 text-teal-500 mx-auto mb-3" />
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-2">
            Track Your Progress
          </h3>
          <p className="text-slate-600 dark:text-slate-400 mb-4">
            Sign in to mark lessons as completed and track your learning journey.
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
