import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap, Search, BookOpen, Clock } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources, progress } from '../services/api';
import { Course, UserProgress } from '../types';
import { useAuth } from '../context/AuthContext';

export default function Courses() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const coursesData = await resources.getCourses();
        setCourses(coursesData);

        if (isAuthenticated) {
          try {
            const progressData = await progress.get();
            setUserProgress(progressData);
          } catch (error) {
            console.error('Failed to fetch progress:', error);
          }
        }
      } catch (error) {
        console.error('Failed to fetch courses:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [isAuthenticated]);

  const getProgress = (courseId: number): number => {
    const courseProgress = userProgress.find((p) => p.course_id === courseId);
    const course = courses.find((c) => c.id === courseId);
    if (!courseProgress || !course || !course.lessons?.length) return 0;
    return Math.round(
      (courseProgress.completed_lessons.length / course.lessons.length) * 100
    );
  };

  const filteredCourses = courses.filter(
    (course) =>
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <PageLayout
      title="Courses"
      subtitle="Structured learning paths for pharmacy education"
      icon={<GraduationCap className="w-6 h-6" />}
      gradient="from-orange-500 to-amber-500"
    >
      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-700 dark:text-white"
          />
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner text="Loading courses..." />
      ) : filteredCourses.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredCourses.map((course, index) => {
            const courseProgress = getProgress(course.id);

            return (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ y: -4 }}
                onClick={() => navigate(`/courses/${course.id}`)}
                className="group cursor-pointer backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl shadow-lg border border-white/30 overflow-hidden"
              >
                {/* Header */}
                <div className="relative h-32 bg-gradient-to-r from-orange-500 to-amber-500 p-4">
                  <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCA0LTRzNCAyIDQgNC0yIDQtNCA0LTQtMi00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
                  <div className="relative z-10">
                    <GraduationCap className="w-10 h-10 text-white/80 mb-2" />
                    <h3 className="text-lg font-bold text-white line-clamp-2">
                      {course.title}
                    </h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  {course.description && (
                    <p className="text-slate-600 dark:text-slate-400 text-sm line-clamp-2 mb-4">
                      {course.description}
                    </p>
                  )}

                  {/* Stats */}
                  <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                    <div className="flex items-center gap-1">
                      <BookOpen className="w-4 h-4" />
                      <span>{course.lessons?.length || 0} lessons</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>~{(course.lessons?.length || 0) * 15} min</span>
                    </div>
                  </div>

                  {/* Progress */}
                  {isAuthenticated && (
                    <div>
                      <div className="flex justify-between text-xs text-slate-500 mb-1">
                        <span>Your progress</span>
                        <span>{courseProgress}%</span>
                      </div>
                      <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${courseProgress}%` }}
                          transition={{ duration: 0.5, ease: 'easeOut' }}
                          className="h-full bg-gradient-to-r from-orange-500 to-amber-500 rounded-full"
                        />
                      </div>
                    </div>
                  )}

                  {!isAuthenticated && (
                    <p className="text-xs text-slate-400 italic">
                      Sign in to track your progress
                    </p>
                  )}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-orange-50 flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-10 h-10 text-orange-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            {searchQuery ? 'No courses found' : 'No courses yet'}
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            {searchQuery
              ? 'Try a different search term'
              : 'Courses coming soon'}
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
