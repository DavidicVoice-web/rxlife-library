import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Video, Search, Play } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import ResourceCard from '../components/ResourceCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';
import { Video as VideoType } from '../types';

export default function Videos() {
  const [videos, setVideos] = useState<VideoType[]>([]);
  const [filteredVideos, setFilteredVideos] = useState<VideoType[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const data = await resources.getVideos();
        setVideos(data);
        setFilteredVideos(data);
      } catch (error) {
        console.error('Failed to fetch videos:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchVideos();
  }, []);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = videos.filter(
        (video) =>
          video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          video.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredVideos(filtered);
    } else {
      setFilteredVideos(videos);
    }
  }, [searchQuery, videos]);

  return (
    <PageLayout
      title="Videos"
      subtitle="Watch pharmacy lectures, tutorials, and educational content"
      icon={<Video className="w-6 h-6" />}
      gradient="from-red-500 to-pink-500"
    >
      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search videos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 focus:outline-none focus:ring-2 focus:ring-red-500/50 text-slate-700 dark:text-white"
          />
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner text="Loading videos..." />
      ) : filteredVideos.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredVideos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <ResourceCard
                type="video"
                title={video.title}
                subtitle={video.duration}
                description={video.description}
                fileUrl={video.file_url}
                thumbnailUrl={video.thumbnail_url}
              />
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
            <Play className="w-10 h-10 text-red-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            {searchQuery ? 'No videos found' : 'No videos yet'}
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            {searchQuery
              ? 'Try a different search term'
              : 'Video content coming soon'}
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
