import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Search } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import ResourceCard from '../components/ResourceCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';
import { Book } from '../types';

export default function Books() {
  const [books, setBooks] = useState<Book[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<Book[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const data = await resources.getBooks();
        setBooks(data);
        setFilteredBooks(data);
      } catch (error) {
        console.error('Failed to fetch books:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBooks();
  }, []);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = books.filter(
        (book) =>
          book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          book.author?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          book.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredBooks(filtered);
    } else {
      setFilteredBooks(books);
    }
  }, [searchQuery, books]);

  return (
    <PageLayout
      title="Books"
      subtitle="Explore our collection of pharmacy textbooks, references, and guides"
      icon={<BookOpen className="w-6 h-6" />}
      gradient="from-blue-500 to-indigo-500"
    >
      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search books..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-slate-700 dark:text-white"
          />
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner text="Loading books..." />
      ) : filteredBooks.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {filteredBooks.map((book, index) => (
            <motion.div
              key={book.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <ResourceCard
                type="book"
                title={book.title}
                subtitle={book.author}
                description={book.description}
                fileUrl={book.file_url}
                thumbnailUrl={book.thumbnail_url}
              />
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-10 h-10 text-blue-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            {searchQuery ? 'No books found' : 'No books yet'}
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            {searchQuery
              ? 'Try a different search term'
              : 'Check back soon for new additions'}
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
