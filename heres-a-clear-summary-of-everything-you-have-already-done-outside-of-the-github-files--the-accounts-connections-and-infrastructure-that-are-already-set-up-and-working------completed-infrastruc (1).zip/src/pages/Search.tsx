import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search as SearchIcon } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import ResourceCard from '../components/ResourceCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';

export default function Search() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const filter = searchParams.get('filter') || 'all';
  
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const searchResources = async () => {
      if (!query.trim()) {
        setResults([]);
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const data = await resources.search(query, filter);
        setResults(data);
      } catch (error) {
        console.error('Search failed:', error);
        setResults([]);
      } finally {
        setIsLoading(false);
      }
    };

    searchResources();
  }, [query, filter]);

  const getResourceType = (item: any): 'book' | 'video' | 'image' | 'dictionary' | 'course' => {
    if (item.author !== undefined) return 'book';
    if (item.duration !== undefined) return 'video';
    if (item.source !== undefined) return 'image';
    if (item.definition !== undefined) return 'dictionary';
    if (item.lessons !== undefined) return 'course';
    return 'book';
  };

  return (
    <PageLayout
      title="Search Results"
      subtitle={query ? `Results for "${query}"${filter !== 'all' ? ` in ${filter}` : ''}` : 'Enter a search query'}
      icon={<SearchIcon className="w-6 h-6" />}
      gradient="from-teal-500 to-blue-500"
    >
      {isLoading ? (
        <LoadingSpinner text="Searching..." />
      ) : results.length > 0 ? (
        <>
          <p className="text-slate-500 dark:text-slate-400 mb-6">
            Found {results.length} result{results.length !== 1 ? 's' : ''}
          </p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
          >
            {results.map((item, index) => {
              const type = getResourceType(item);
              return (
                <motion.div
                  key={`${type}-${item.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <ResourceCard
                    type={type}
                    title={item.title || item.term}
                    subtitle={item.author || item.duration || item.source}
                    description={item.description || item.definition}
                    fileUrl={item.file_url}
                    thumbnailUrl={item.thumbnail_url}
                  />
                </motion.div>
              );
            })}
          </motion.div>
        </>
      ) : query ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
            <SearchIcon className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            No results found
          </h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            We couldn't find anything matching "{query}". Try different keywords or browse categories.
          </p>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
            <SearchIcon className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            Start searching
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            Use the search bar above to find pharmacy resources.
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
