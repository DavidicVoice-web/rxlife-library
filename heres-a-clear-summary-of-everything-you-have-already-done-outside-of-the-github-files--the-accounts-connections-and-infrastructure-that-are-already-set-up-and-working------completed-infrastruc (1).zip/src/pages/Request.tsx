import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquarePlus, Send, Check, AlertCircle, Loader2 } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import { requests } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Request() {
  const { profile } = useAuth();
  const [userName, setUserName] = useState(profile?.username || '');
  const [requestText, setRequestText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!requestText.trim()) {
      setError('Please describe what you\'re looking for');
      return;
    }

    setIsSubmitting(true);

    try {
      await requests.submit({
        user_name: userName || undefined,
        request_text: requestText,
      });
      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <PageLayout
        title="Request Resource"
        subtitle="Can't find what you need? Ask the community!"
        icon={<MessageSquarePlus className="w-6 h-6" />}
        gradient="from-indigo-500 to-purple-500"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-lg mx-auto text-center py-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6"
          >
            <Check className="w-10 h-10 text-green-500" />
          </motion.div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">
            Request Submitted!
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            Thank you for your request. Our community and admins will work to find what you're looking for.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setSuccess(false);
              setRequestText('');
            }}
            className="px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl font-medium"
          >
            Submit Another Request
          </motion.button>
        </motion.div>
      </PageLayout>
    );
  }

  return (
    <PageLayout
      title="Request Resource"
      subtitle="Can't find what you need? Ask the community!"
      icon={<MessageSquarePlus className="w-6 h-6" />}
      gradient="from-indigo-500 to-purple-500"
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-xl mx-auto"
      >
        <div className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600"
              >
                <AlertCircle className="w-5 h-5 shrink-0" />
                {error}
              </motion.div>
            )}

            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Your Name (optional)
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Enter your name"
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-700 dark:text-white"
              />
            </div>

            {/* Request */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                What are you looking for? *
              </label>
              <textarea
                value={requestText}
                onChange={(e) => setRequestText(e.target.value)}
                rows={5}
                required
                placeholder="Describe the resource you need. Include details like:
• Book title or author
• Topic or subject
• Type (textbook, video, image, etc.)
• Any other helpful information"
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-700 dark:text-white resize-none"
              />
            </div>

            {/* Info */}
            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl">
              <p className="text-sm text-indigo-700 dark:text-indigo-300">
                💡 <strong>Tip:</strong> Be as specific as possible. Include edition numbers, publication years, or any identifying details that might help us find the right resource.
              </p>
            </div>

            {/* Submit */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl font-medium shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Submit Request
                </>
              )}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </PageLayout>
  );
}
