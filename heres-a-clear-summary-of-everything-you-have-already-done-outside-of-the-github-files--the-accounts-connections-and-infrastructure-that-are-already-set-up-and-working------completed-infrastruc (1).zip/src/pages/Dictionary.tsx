import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BookText, Search, ChevronRight } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';
import { DictionaryTerm } from '../types';

export default function Dictionary() {
  const [terms, setTerms] = useState<DictionaryTerm[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [expandedTerm, setExpandedTerm] = useState<number | null>(null);

  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  useEffect(() => {
    const fetchTerms = async () => {
      try {
        const data = await resources.getDictionary();
        setTerms(data);
      } catch (error) {
        console.error('Failed to fetch dictionary:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTerms();
  }, []);

  const filteredTerms = useMemo(() => {
    let filtered = terms;

    if (searchQuery.trim()) {
      filtered = filtered.filter(
        (term) =>
          term.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
          term.definition.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedLetter) {
      filtered = filtered.filter((term) =>
        term.term.toUpperCase().startsWith(selectedLetter)
      );
    }

    return filtered.sort((a, b) => a.term.localeCompare(b.term));
  }, [terms, searchQuery, selectedLetter]);

  const groupedTerms = useMemo(() => {
    const groups: Record<string, DictionaryTerm[]> = {};
    filteredTerms.forEach((term) => {
      const letter = term.term[0]?.toUpperCase() || '#';
      if (!groups[letter]) groups[letter] = [];
      groups[letter].push(term);
    });
    return groups;
  }, [filteredTerms]);

  return (
    <PageLayout
      title="Dictionary"
      subtitle="Comprehensive glossary of pharmacy and medical terms"
      icon={<BookText className="w-6 h-6" />}
      gradient="from-purple-500 to-violet-500"
    >
      {/* Search */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search terms or definitions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-slate-700 dark:text-white"
          />
        </div>
      </div>

      {/* Alphabet Filter */}
      <div className="mb-8 overflow-x-auto pb-2">
        <div className="flex gap-1 min-w-max">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelectedLetter(null)}
            className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${
              selectedLetter === null
                ? 'bg-gradient-to-r from-purple-500 to-violet-500 text-white'
                : 'bg-white/70 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:bg-purple-100'
            }`}
          >
            All
          </motion.button>
          {alphabet.map((letter) => (
            <motion.button
              key={letter}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedLetter(letter)}
              className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${
                selectedLetter === letter
                  ? 'bg-gradient-to-r from-purple-500 to-violet-500 text-white'
                  : 'bg-white/70 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:bg-purple-100'
              }`}
            >
              {letter}
            </motion.button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner text="Loading dictionary..." />
      ) : filteredTerms.length > 0 ? (
        <div className="space-y-8">
          {Object.entries(groupedTerms).map(([letter, letterTerms]) => (
            <motion.div
              key={letter}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-purple-500 to-violet-500 flex items-center justify-center text-white font-bold">
                  {letter}
                </div>
                <span className="text-sm text-slate-500">
                  {letterTerms.length} term{letterTerms.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="space-y-2">
                {letterTerms.map((term) => (
                  <motion.div
                    key={term.id}
                    layout
                    className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 overflow-hidden"
                  >
                    <button
                      onClick={() =>
                        setExpandedTerm(expandedTerm === term.id ? null : term.id)
                      }
                      className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-purple-50/50 dark:hover:bg-purple-900/20 transition-colors"
                    >
                      <span className="font-semibold text-slate-800 dark:text-white">
                        {term.term}
                      </span>
                      <motion.div
                        animate={{ rotate: expandedTerm === term.id ? 90 : 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ChevronRight className="w-5 h-5 text-slate-400" />
                      </motion.div>
                    </button>
                    
                    <AnimatePresence>
                      {expandedTerm === term.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 pt-0">
                            <div className="pt-3 border-t border-slate-100 dark:border-slate-700">
                              <p className="text-slate-600 dark:text-slate-400">
                                {term.definition}
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-purple-50 flex items-center justify-center mx-auto mb-4">
            <BookText className="w-10 h-10 text-purple-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            {searchQuery || selectedLetter ? 'No terms found' : 'No dictionary entries yet'}
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            {searchQuery || selectedLetter
              ? 'Try a different search or filter'
              : 'Dictionary entries coming soon'}
          </p>
        </motion.div>
      )}
    </PageLayout>
  );
}
