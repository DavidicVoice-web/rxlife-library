import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Upload as UploadIcon, FileText, Video, Image, X, Check, AlertCircle, Loader2 } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import { useAuth } from '../context/AuthContext';
import { uploads } from '../services/api';

type ResourceType = 'book' | 'video' | 'image';

const resourceTypes: { value: ResourceType; label: string; icon: typeof FileText; accept: string }[] = [
  { value: 'book', label: 'Book / PDF', icon: FileText, accept: '.pdf,.doc,.docx' },
  { value: 'video', label: 'Video', icon: Video, accept: '.mp4,.webm,.mov' },
  { value: 'image', label: 'Image', icon: Image, accept: '.jpg,.jpeg,.png,.gif,.webp' },
];

export default function Upload() {
  const navigate = useNavigate();
  const { isAuthenticated, profile } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [type, setType] = useState<ResourceType>('book');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [author, setAuthor] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isAuthenticated) {
    return (
      <PageLayout
        title="Upload"
        subtitle="Share your pharmacy resources with the community"
        icon={<UploadIcon className="w-6 h-6" />}
        gradient="from-teal-500 to-blue-500"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-lg mx-auto text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-6">
            <UploadIcon className="w-10 h-10 text-teal-400" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">
            Sign in to Upload
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            You need to be logged in to upload resources. Your contributions help the pharmacy community grow!
          </p>
        </motion.div>
      </PageLayout>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setError('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Please enter a title');
      return;
    }

    if (!file) {
      setError('Please select a file');
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('type', type);
      formData.append('title', title);
      formData.append('description', description);
      formData.append('file', file);
      
      if (type === 'book' && author) {
        formData.append('author', author);
      }

      await uploads.submit(formData);
      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Failed to upload. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <PageLayout
        title="Upload"
        subtitle="Share your pharmacy resources with the community"
        icon={<UploadIcon className="w-6 h-6" />}
        gradient="from-teal-500 to-blue-500"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-lg mx-auto text-center py-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6"
          >
            <Check className="w-10 h-10 text-green-500" />
          </motion.div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">
            Upload Submitted!
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mb-6">
            Thank you for contributing! Your upload is pending admin approval. 
            You'll be notified once it's reviewed.
          </p>
          <div className="flex justify-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setSuccess(false);
                setTitle('');
                setDescription('');
                setAuthor('');
                setFile(null);
              }}
              className="px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-500 text-white rounded-xl font-medium"
            >
              Upload Another
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate('/')}
              className="px-6 py-3 bg-slate-100 text-slate-700 rounded-xl font-medium"
            >
              Go Home
            </motion.button>
          </div>
        </motion.div>
      </PageLayout>
    );
  }

  const selectedType = resourceTypes.find((t) => t.value === type)!;

  return (
    <PageLayout
      title="Upload"
      subtitle="Share your pharmacy resources with the community"
      icon={<UploadIcon className="w-6 h-6" />}
      gradient="from-teal-500 to-blue-500"
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto"
      >
        <div className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-4 bg-red-50 border border-red-100 rounded-xl text-red-600"
              >
                <AlertCircle className="w-5 h-5 shrink-0" />
                {error}
              </motion.div>
            )}

            {/* Resource Type */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                Resource Type
              </label>
              <div className="grid grid-cols-3 gap-3">
                {resourceTypes.map((rt) => {
                  const Icon = rt.icon;
                  return (
                    <motion.button
                      key={rt.value}
                      type="button"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setType(rt.value);
                        setFile(null);
                      }}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        type === rt.value
                          ? 'border-teal-500 bg-teal-50 dark:bg-teal-900/30'
                          : 'border-slate-200 dark:border-slate-700 hover:border-teal-300'
                      }`}
                    >
                      <Icon className={`w-6 h-6 mx-auto mb-2 ${
                        type === rt.value ? 'text-teal-600' : 'text-slate-400'
                      }`} />
                      <span className={`text-sm font-medium ${
                        type === rt.value ? 'text-teal-700 dark:text-teal-400' : 'text-slate-600 dark:text-slate-400'
                      }`}>
                        {rt.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                placeholder="Enter resource title"
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 dark:text-white"
              />
            </div>

            {/* Author (for books) */}
            {type === 'book' && (
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Author
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="Enter author name"
                  className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 dark:text-white"
                />
              </div>
            )}

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Describe this resource..."
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500/50 text-slate-700 dark:text-white resize-none"
              />
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                File *
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept={selectedType.accept}
                onChange={handleFileChange}
                className="hidden"
              />
              
              {file ? (
                <div className="flex items-center gap-3 p-4 bg-teal-50 dark:bg-teal-900/30 rounded-xl border-2 border-teal-200 dark:border-teal-800">
                  <selectedType.icon className="w-8 h-8 text-teal-600" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-800 dark:text-white truncate">
                      {file.name}
                    </p>
                    <p className="text-sm text-slate-500">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFile(null)}
                    className="p-2 rounded-lg hover:bg-teal-100 dark:hover:bg-teal-900/50 text-slate-500"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full p-8 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl hover:border-teal-400 hover:bg-teal-50/50 dark:hover:bg-teal-900/20 transition-colors"
                >
                  <UploadIcon className="w-10 h-10 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-600 dark:text-slate-400">
                    Click to select a file
                  </p>
                  <p className="text-sm text-slate-400 mt-1">
                    Accepted: {selectedType.accept}
                  </p>
                </motion.button>
              )}
            </div>

            {/* Submitter Info */}
            <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Submitting as: <span className="font-medium text-slate-700 dark:text-slate-300">{profile?.username}</span>
              </p>
              <p className="text-xs text-slate-400 mt-1">
                All uploads are reviewed by admins before being published.
              </p>
            </div>

            {/* Submit */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl font-medium shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <UploadIcon className="w-5 h-5" />
                  Submit for Review
                </>
              )}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </PageLayout>
  );
}
