import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image as ImageIcon, Search, X, Download } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';
import { Image as ImageType } from '../types';

export default function Images() {
  const [images, setImages] = useState<ImageType[]>([]);
  const [filteredImages, setFilteredImages] = useState<ImageType[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedImage, setSelectedImage] = useState<ImageType | null>(null);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        const data = await resources.getImages();
        setImages(data);
        setFilteredImages(data);
      } catch (error) {
        console.error('Failed to fetch images:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchImages();
  }, []);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = images.filter(
        (image) =>
          image.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          image.source?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          image.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredImages(filtered);
    } else {
      setFilteredImages(images);
    }
  }, [searchQuery, images]);

  return (
    <PageLayout
      title="Images"
      subtitle="Browse pharmacy diagrams, charts, and visual resources"
      icon={<ImageIcon className="w-6 h-6" />}
      gradient="from-green-500 to-emerald-500"
    >
      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search images..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 focus:outline-none focus:ring-2 focus:ring-green-500/50 text-slate-700 dark:text-white"
          />
        </div>
      </div>

      {isLoading ? (
        <LoadingSpinner text="Loading images..." />
      ) : filteredImages.length > 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
        >
          {filteredImages.map((image, index) => (
            <motion.div
              key={image.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.03 }}
              whileHover={{ y: -4 }}
              onClick={() => setSelectedImage(image)}
              className="group relative aspect-square cursor-pointer rounded-xl overflow-hidden backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 border border-white/30"
            >
              {image.file_url ? (
                <img
                  src={image.file_url}
                  alt={image.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-green-100 to-emerald-100 flex items-center justify-center">
                  <ImageIcon className="w-10 h-10 text-green-300" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <p className="text-white text-sm font-medium line-clamp-2">
                    {image.title}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-4">
            <ImageIcon className="w-10 h-10 text-green-300" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 dark:text-white mb-2">
            {searchQuery ? 'No images found' : 'No images yet'}
          </h3>
          <p className="text-slate-500 dark:text-slate-400">
            {searchQuery
              ? 'Try a different search term'
              : 'Image gallery coming soon'}
          </p>
        </motion.div>
      )}

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl max-h-[90vh] backdrop-blur-xl bg-white/90 dark:bg-slate-900/90 rounded-2xl overflow-hidden"
            >
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute right-4 top-4 z-10 p-2 bg-black/50 rounded-full text-white hover:bg-black/70 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              {selectedImage.file_url && (
                <img
                  src={selectedImage.file_url}
                  alt={selectedImage.title}
                  className="max-w-full max-h-[70vh] object-contain"
                />
              )}
              
              <div className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-2">
                  {selectedImage.title}
                </h3>
                {selectedImage.source && (
                  <p className="text-sm text-slate-500 mb-2">Source: {selectedImage.source}</p>
                )}
                {selectedImage.description && (
                  <p className="text-slate-600 dark:text-slate-400 mb-4">
                    {selectedImage.description}
                  </p>
                )}
                {selectedImage.file_url && (
                  <a
                    href={selectedImage.file_url}
                    download
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl text-sm font-medium"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </PageLayout>
  );
}
