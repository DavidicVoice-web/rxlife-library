import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Video, GraduationCap, Sparkles, ArrowRight, Pill, FlaskConical, Heart } from 'lucide-react';
import ResourceCard from '../components/ResourceCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { resources } from '../services/api';
import { Book, Video as VideoType, Course } from '../types';

export default function Home() {
  const navigate = useNavigate();
  const [featuredBooks, setFeaturedBooks] = useState<Book[]>([]);
  const [featuredVideos, setFeaturedVideos] = useState<VideoType[]>([]);
  const [featuredCourses, setFeaturedCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const [books, videos, courses] = await Promise.all([
          resources.getBooks().catch(() => []),
          resources.getVideos().catch(() => []),
          resources.getCourses().catch(() => []),
        ]);
        setFeaturedBooks(books.slice(0, 3));
        setFeaturedVideos(videos.slice(0, 2));
        setFeaturedCourses(courses.slice(0, 2));
      } catch (error) {
        console.error('Failed to fetch featured content:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFeatured();
  }, []);

  const features = [
    { icon: Pill, title: 'Pharmacy Resources', desc: 'Access thousands of books, videos, and images' },
    { icon: FlaskConical, title: 'Drug Information', desc: 'Comprehensive dictionary of medical terms' },
    { icon: Heart, title: 'Community Driven', desc: 'Upload and share knowledge with peers' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-teal-50 via-blue-50 to-white dark:from-slate-900 dark:via-slate-800 dark:to-slate-900" />
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 180, 360],
            }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-teal-400/20 to-blue-400/20 rounded-full blur-3xl"
          />
          <motion.div
            animate={{ 
              scale: [1.2, 1, 1.2],
              rotate: [360, 180, 0],
            }}
            transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
            className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-tr from-purple-400/10 to-pink-400/10 rounded-full blur-3xl"
          />
        </div>

        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-100/80 dark:bg-teal-900/30 rounded-full mb-6">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-700 dark:text-teal-300">
                Your Pharmacy Knowledge Hub
              </span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-teal-600 via-blue-600 to-teal-600 bg-clip-text text-transparent">
                RxLife Network
              </span>
              <br />
              <span className="text-slate-800 dark:text-white">Library</span>
            </h1>

            <p className="text-lg md:text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-8">
              A comprehensive digital library for pharmacy students, pharmacists, and researchers. 
              Access books, videos, courses, and more — all in one place.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/books')}
                className="px-6 py-3 bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-xl font-medium shadow-xl shadow-teal-500/25 flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                Explore Library
                <ArrowRight className="w-4 h-4" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/courses')}
                className="px-6 py-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-white rounded-xl font-medium shadow-lg border border-slate-200 dark:border-slate-700 flex items-center gap-2"
              >
                <GraduationCap className="w-5 h-5" />
                Start Learning
              </motion.button>
            </div>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -5 }}
                className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl p-6 shadow-lg border border-white/30"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-blue-500 flex items-center justify-center mb-4 shadow-lg shadow-teal-500/20">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-slate-800 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-sm">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          {isLoading ? (
            <LoadingSpinner text="Loading featured content..." />
          ) : (
            <>
              {/* Featured Books */}
              {featuredBooks.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="mb-12"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center">
                        <BookOpen className="w-5 h-5 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
                        Featured Books
                      </h2>
                    </div>
                    <motion.button
                      whileHover={{ x: 5 }}
                      onClick={() => navigate('/books')}
                      className="flex items-center gap-2 text-teal-600 font-medium"
                    >
                      View All <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {featuredBooks.map((book) => (
                      <ResourceCard
                        key={book.id}
                        type="book"
                        title={book.title}
                        subtitle={book.author}
                        description={book.description}
                        fileUrl={book.file_url}
                        thumbnailUrl={book.thumbnail_url}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Featured Videos */}
              {featuredVideos.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="mb-12"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center">
                        <Video className="w-5 h-5 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
                        Featured Videos
                      </h2>
                    </div>
                    <motion.button
                      whileHover={{ x: 5 }}
                      onClick={() => navigate('/videos')}
                      className="flex items-center gap-2 text-teal-600 font-medium"
                    >
                      View All <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {featuredVideos.map((video) => (
                      <ResourceCard
                        key={video.id}
                        type="video"
                        title={video.title}
                        subtitle={video.duration}
                        description={video.description}
                        fileUrl={video.file_url}
                        thumbnailUrl={video.thumbnail_url}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Featured Courses */}
              {featuredCourses.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 flex items-center justify-center">
                        <GraduationCap className="w-5 h-5 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
                        Featured Courses
                      </h2>
                    </div>
                    <motion.button
                      whileHover={{ x: 5 }}
                      onClick={() => navigate('/courses')}
                      className="flex items-center gap-2 text-teal-600 font-medium"
                    >
                      View All <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {featuredCourses.map((course) => (
                      <ResourceCard
                        key={course.id}
                        type="course"
                        title={course.title}
                        subtitle={`${course.lessons?.length || 0} lessons`}
                        description={course.description}
                        onClick={() => navigate(`/courses/${course.id}`)}
                      />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Empty state */}
              {featuredBooks.length === 0 && featuredVideos.length === 0 && featuredCourses.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-16"
                >
                  <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-10 h-10 text-slate-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-700 mb-2">
                    No content yet
                  </h3>
                  <p className="text-slate-500 max-w-md mx-auto">
                    The library is waiting for its first resources. Check back soon or be the first to contribute!
                  </p>
                </motion.div>
              )}
            </>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative backdrop-blur-xl bg-gradient-to-r from-teal-500 to-blue-600 rounded-3xl p-8 md:p-12 text-center overflow-hidden"
          >
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCA0LTRzNCAyIDQgNC0yIDQtNCA0LTQtMi00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30" />
            
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 relative z-10">
              Can't find what you're looking for?
            </h2>
            <p className="text-white/80 mb-8 max-w-lg mx-auto relative z-10">
              Request specific resources and our community will help you find them. 
              Or contribute your own knowledge to help others!
            </p>
            <div className="flex flex-wrap justify-center gap-4 relative z-10">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/request')}
                className="px-6 py-3 bg-white text-teal-600 rounded-xl font-medium shadow-xl"
              >
                Request Resource
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/upload')}
                className="px-6 py-3 bg-white/20 text-white rounded-xl font-medium border border-white/30"
              >
                Upload Content
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
