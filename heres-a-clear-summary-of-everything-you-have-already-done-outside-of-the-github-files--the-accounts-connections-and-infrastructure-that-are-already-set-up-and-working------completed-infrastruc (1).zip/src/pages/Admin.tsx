import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Shield,
  Lock,
  Loader2,
  AlertCircle,
  Check,
  X,
  Clock,
  MessageSquare,
  BookOpen,
  Video,
  Image,
  BookText,
  GraduationCap,
  Plus,
  Trash2,
  LogOut,
} from 'lucide-react';
import { useAdmin } from '../context/AdminContext';
import { admin, resources } from '../services/api';
import { PendingUpload, UserRequest } from '../types';

type Tab = 'pending' | 'requests' | 'resources' | 'add';
type ResourceType = 'book' | 'video' | 'image' | 'dictionary' | 'course';

const tabs: { id: Tab; label: string; icon: typeof Clock }[] = [
  { id: 'pending', label: 'Pending', icon: Clock },
  { id: 'requests', label: 'Requests', icon: MessageSquare },
  { id: 'resources', label: 'Manage', icon: BookOpen },
  { id: 'add', label: 'Add New', icon: Plus },
];

export default function Admin() {
  const { isAdminAuthenticated, adminLogin, adminLogout } = useAdmin();
  const [password, setPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('pending');

  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen pt-24 pb-32 px-4 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 p-8"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
              Admin Panel
            </h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">
              Enter admin password to continue
            </p>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setIsLoggingIn(true);
              setLoginError('');

              try {
                await admin.login(password);
                adminLogin(password);
              } catch (err: any) {
                setLoginError(err.message || 'Invalid password');
              } finally {
                setIsLoggingIn(false);
              }
            }}
            className="space-y-4"
          >
            {loginError && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm"
              >
                <AlertCircle className="w-4 h-4" />
                {loginError}
              </motion.div>
            )}

            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Admin password"
                required
                className="w-full pl-12 pr-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-red-500/50 text-slate-700 dark:text-white"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-xl font-medium flex items-center justify-center gap-2"
            >
              {isLoggingIn ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Shield className="w-5 h-5" />
                  Access Panel
                </>
              )}
            </motion.button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-32 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center shadow-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
                Admin Panel
              </h1>
              <p className="text-slate-500 dark:text-slate-400">
                Manage content and requests
              </p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={adminLogout}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl hover:bg-red-50 hover:text-red-600"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </motion.button>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg'
                  : 'bg-white/70 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </motion.button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'pending' && <PendingUploads key="pending" />}
          {activeTab === 'requests' && <UserRequests key="requests" />}
          {activeTab === 'resources' && <ManageResources key="resources" />}
          {activeTab === 'add' && <AddResource key="add" />}
        </AnimatePresence>
      </div>
    </div>
  );
}

// Pending Uploads Component
function PendingUploads() {
  const [pending, setPending] = useState<PendingUpload[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  useEffect(() => {
    fetchPending();
  }, []);

  const fetchPending = async () => {
    try {
      const data = await admin.getPending();
      setPending(data);
    } catch (error) {
      console.error('Failed to fetch pending:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = async (id: number, action: 'approve' | 'reject') => {
    setActionLoading(id);
    try {
      if (action === 'approve') {
        await admin.approvePending(id);
      } else {
        await admin.rejectPending(id);
      }
      setPending(pending.filter((p) => p.id !== id));
    } catch (error) {
      console.error(`Failed to ${action}:`, error);
    } finally {
      setActionLoading(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4"
    >
      {pending.length > 0 ? (
        pending.map((item) => (
          <div
            key={item.id}
            className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 p-4"
          >
            <div className="flex items-start gap-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                item.type === 'book' ? 'bg-blue-100' :
                item.type === 'video' ? 'bg-red-100' : 'bg-green-100'
              }`}>
                {item.type === 'book' && <BookOpen className="w-5 h-5 text-blue-600" />}
                {item.type === 'video' && <Video className="w-5 h-5 text-red-600" />}
                {item.type === 'image' && <Image className="w-5 h-5 text-green-600" />}
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-slate-800 dark:text-white">
                  {item.data.title}
                </h3>
                <p className="text-sm text-slate-500">
                  Submitted by: {item.submitted_by}
                </p>
                {item.data.description && (
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                    {item.data.description}
                  </p>
                )}
              </div>

              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleAction(item.id, 'approve')}
                  disabled={actionLoading === item.id}
                  className="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 disabled:opacity-50"
                >
                  {actionLoading === item.id ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Check className="w-5 h-5" />
                  )}
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleAction(item.id, 'reject')}
                  disabled={actionLoading === item.id}
                  className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 disabled:opacity-50"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-16 text-slate-500">
          <Clock className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>No pending uploads</p>
        </div>
      )}
    </motion.div>
  );
}

// User Requests Component
function UserRequests() {
  const [userRequests, setUserRequests] = useState<UserRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      const data = await admin.getRequests();
      setUserRequests(data);
    } catch (error) {
      console.error('Failed to fetch requests:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResolve = async (id: number) => {
    try {
      await admin.resolveRequest(id);
      setUserRequests(
        userRequests.map((r) => (r.id === id ? { ...r, resolved: true } : r))
      );
    } catch (error) {
      console.error('Failed to resolve:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4"
    >
      {userRequests.length > 0 ? (
        userRequests.map((request) => (
          <div
            key={request.id}
            className={`backdrop-blur-xl rounded-xl border p-4 ${
              request.resolved
                ? 'bg-green-50/70 border-green-200'
                : 'bg-white/70 dark:bg-slate-800/70 border-white/30'
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {request.user_name && (
                    <span className="font-medium text-slate-800 dark:text-white">
                      {request.user_name}
                    </span>
                  )}
                  <span className="text-xs text-slate-400">
                    {new Date(request.created_at).toLocaleDateString()}
                  </span>
                  {request.resolved && (
                    <span className="text-xs px-2 py-0.5 bg-green-200 text-green-700 rounded-full">
                      Resolved
                    </span>
                  )}
                </div>
                <p className="text-slate-600 dark:text-slate-400">
                  {request.request_text}
                </p>
              </div>

              {!request.resolved && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleResolve(request.id)}
                  className="shrink-0 px-3 py-1.5 bg-green-100 text-green-600 rounded-lg text-sm font-medium hover:bg-green-200"
                >
                  Mark Resolved
                </motion.button>
              )}
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-16 text-slate-500">
          <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>No user requests</p>
        </div>
      )}
    </motion.div>
  );
}

// Manage Resources Component
function ManageResources() {
  const [activeType, setActiveType] = useState<ResourceType>('book');
  const [items, setItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const types: { id: ResourceType; label: string; icon: typeof BookOpen }[] = [
    { id: 'book', label: 'Books', icon: BookOpen },
    { id: 'video', label: 'Videos', icon: Video },
    { id: 'image', label: 'Images', icon: Image },
    { id: 'dictionary', label: 'Dictionary', icon: BookText },
    { id: 'course', label: 'Courses', icon: GraduationCap },
  ];

  useEffect(() => {
    fetchResources();
  }, [activeType]);

  const fetchResources = async () => {
    setIsLoading(true);
    try {
      let data: any[] = [];
      switch (activeType) {
        case 'book':
          data = await resources.getBooks();
          break;
        case 'video':
          data = await resources.getVideos();
          break;
        case 'image':
          data = await resources.getImages();
          break;
        case 'dictionary':
          data = await resources.getDictionary();
          break;
        case 'course':
          data = await resources.getCourses();
          break;
      }
      setItems(data);
    } catch (error) {
      console.error('Failed to fetch resources:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this resource?')) return;
    
    try {
      await admin.deleteResource(activeType, id);
      setItems(items.filter((i) => i.id !== id));
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      {/* Type Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {types.map((type) => (
          <button
            key={type.id}
            onClick={() => setActiveType(type.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              activeType === type.id
                ? 'bg-slate-800 dark:bg-white text-white dark:text-slate-800'
                : 'bg-white/70 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300'
            }`}
          >
            <type.icon className="w-4 h-4" />
            {type.label}
          </button>
        ))}
      </div>

      {/* Resources List */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
        </div>
      ) : items.length > 0 ? (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-xl border border-white/30 p-4 flex items-center justify-between gap-4"
            >
              <div className="min-w-0">
                <h3 className="font-medium text-slate-800 dark:text-white truncate">
                  {item.title || item.term}
                </h3>
                {item.description && (
                  <p className="text-sm text-slate-500 truncate">{item.description}</p>
                )}
                {item.definition && (
                  <p className="text-sm text-slate-500 truncate">{item.definition}</p>
                )}
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleDelete(item.id)}
                className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
              >
                <Trash2 className="w-4 h-4" />
              </motion.button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-slate-500">
          <p>No {activeType}s found</p>
        </div>
      )}
    </motion.div>
  );
}

// Add Resource Component
function AddResource() {
  const [type, setType] = useState<ResourceType>('book');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [extra, setExtra] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [lessons, setLessons] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const types: { id: ResourceType; label: string }[] = [
    { id: 'book', label: 'Book' },
    { id: 'video', label: 'Video' },
    { id: 'image', label: 'Image' },
    { id: 'dictionary', label: 'Dictionary Term' },
    { id: 'course', label: 'Course' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let data: any = {};
      
      if (type === 'dictionary') {
        data = { term: title, definition: description };
      } else if (type === 'course') {
        data = {
          title,
          description,
          lessons: lessons.split('\n').filter((l) => l.trim()),
        };
      } else {
        data = {
          title,
          description,
          file_url: fileUrl || undefined,
        };
        if (type === 'book') data.author = extra;
        if (type === 'video') data.duration = extra;
        if (type === 'image') data.source = extra;
      }

      await admin.addResource(type, data);
      setSuccess(true);
      setTitle('');
      setDescription('');
      setExtra('');
      setFileUrl('');
      setLessons('');
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Failed to add resource:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-2xl"
    >
      <div className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 p-6">
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 p-4 bg-green-50 border border-green-100 rounded-xl text-green-600 mb-6"
          >
            <Check className="w-5 h-5" />
            Resource added successfully!
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Type */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Type
            </label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as ResourceType)}
              className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-700 dark:text-white"
            >
              {types.map((t) => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </div>

          {/* Title / Term */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              {type === 'dictionary' ? 'Term' : 'Title'}
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-700 dark:text-white"
            />
          </div>

          {/* Description / Definition */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              {type === 'dictionary' ? 'Definition' : 'Description'}
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-slate-700 dark:text-white resize-none"
            />
          </div>

          {/* Extra fields */}
          {type === 'book' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Author
              </label>
              <input
                type="text"
                value={extra}
                onChange={(e) => setExtra(e.target.value)}
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none text-slate-700 dark:text-white"
              />
            </div>
          )}

          {type === 'video' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Duration
              </label>
              <input
                type="text"
                value={extra}
                onChange={(e) => setExtra(e.target.value)}
                placeholder="e.g., 15:30"
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none text-slate-700 dark:text-white"
              />
            </div>
          )}

          {type === 'image' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Source
              </label>
              <input
                type="text"
                value={extra}
                onChange={(e) => setExtra(e.target.value)}
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none text-slate-700 dark:text-white"
              />
            </div>
          )}

          {type === 'course' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Lessons (one per line)
              </label>
              <textarea
                value={lessons}
                onChange={(e) => setLessons(e.target.value)}
                rows={5}
                placeholder="Introduction&#10;Chapter 1&#10;Chapter 2"
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none text-slate-700 dark:text-white resize-none"
              />
            </div>
          )}

          {/* File URL */}
          {type !== 'dictionary' && type !== 'course' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                File URL
              </label>
              <input
                type="url"
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-4 py-3 bg-slate-100/80 dark:bg-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 focus:outline-none text-slate-700 dark:text-white"
              />
            </div>
          )}

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-xl font-medium flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Plus className="w-5 h-5" />
                Add Resource
              </>
            )}
          </motion.button>
        </form>
      </div>
    </motion.div>
  );
}
