import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, GraduationCap, Calendar, Key, LogOut, Loader2, Check, AlertCircle } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import { useAuth } from '../context/AuthContext';
import { auth } from '../services/api';

export default function Profile() {
  const navigate = useNavigate();
  const { user, profile, isAuthenticated, logout } = useAuth();
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [passwordResetStatus, setPasswordResetStatus] = useState<'idle' | 'success' | 'error'>('idle');

  if (!isAuthenticated || !user) {
    return (
      <PageLayout
        title="Profile"
        subtitle="View and manage your account"
        icon={<User className="w-6 h-6" />}
        gradient="from-purple-500 to-pink-500"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-lg mx-auto text-center py-16"
        >
          <div className="w-20 h-20 rounded-full bg-purple-50 flex items-center justify-center mx-auto mb-6">
            <User className="w-10 h-10 text-purple-400" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">
            Not Signed In
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Please sign in to view your profile.
          </p>
        </motion.div>
      </PageLayout>
    );
  }

  const handlePasswordReset = async () => {
    setIsResettingPassword(true);
    setPasswordResetStatus('idle');

    try {
      await auth.resetPassword(user.email);
      setPasswordResetStatus('success');
    } catch (error) {
      console.error('Password reset failed:', error);
      setPasswordResetStatus('error');
    } finally {
      setIsResettingPassword(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const profileItems = [
    {
      icon: User,
      label: 'Username',
      value: profile?.username || 'N/A',
    },
    {
      icon: Mail,
      label: 'Email',
      value: user.email,
    },
    {
      icon: GraduationCap,
      label: 'Academic Level',
      value: profile?.academic_level || 'Not specified',
    },
    {
      icon: Calendar,
      label: 'Member Since',
      value: profile?.created_at
        ? new Date(profile.created_at).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })
        : 'N/A',
    },
  ];

  return (
    <PageLayout
      title="Profile"
      subtitle="View and manage your account"
      icon={<User className="w-6 h-6" />}
      gradient="from-purple-500 to-pink-500"
    >
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 overflow-hidden"
        >
          {/* Header */}
          <div className="relative h-32 bg-gradient-to-r from-purple-500 to-pink-500">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCA0LTRzNCAyIDQgNC0yIDQtNCA0LTQtMi00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30" />
          </div>
          
          {/* Avatar */}
          <div className="relative px-6">
            <div className="absolute -top-12 w-24 h-24 rounded-2xl bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center text-white text-3xl font-bold shadow-xl border-4 border-white dark:border-slate-800">
              {profile?.username?.substring(0, 2) || 'Rx'}
            </div>
          </div>

          {/* Info */}
          <div className="pt-16 px-6 pb-6">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-1">
              {profile?.username || 'User'}
            </h2>
            <p className="text-slate-500 dark:text-slate-400 mb-6">
              {profile?.academic_level || 'Pharmacy Professional'}
            </p>

            <div className="space-y-4">
              {profileItems.map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl"
                >
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      {item.label}
                    </p>
                    <p className="font-medium text-slate-800 dark:text-white">
                      {item.value}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="backdrop-blur-xl bg-white/70 dark:bg-slate-800/70 rounded-2xl border border-white/30 p-6 space-y-4"
        >
          <h3 className="font-semibold text-slate-800 dark:text-white mb-4">
            Account Actions
          </h3>

          {/* Password Reset */}
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                <Key className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="font-medium text-slate-800 dark:text-white">
                  Reset Password
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Send a password reset email
                </p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handlePasswordReset}
              disabled={isResettingPassword}
              className="px-4 py-2 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded-lg font-medium text-sm flex items-center gap-2 disabled:opacity-50"
            >
              {isResettingPassword ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : passwordResetStatus === 'success' ? (
                <>
                  <Check className="w-4 h-4" />
                  Sent!
                </>
              ) : (
                'Reset'
              )}
            </motion.button>
          </div>

          {passwordResetStatus === 'success' && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3 bg-green-50 border border-green-100 rounded-xl text-green-600 text-sm"
            >
              <Check className="w-4 h-4" />
              Password reset email sent! Check your inbox.
            </motion.div>
          )}

          {passwordResetStatus === 'error' && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm"
            >
              <AlertCircle className="w-4 h-4" />
              Failed to send reset email. Please try again.
            </motion.div>
          )}

          {/* Logout */}
          <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                <LogOut className="w-5 h-5 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <p className="font-medium text-slate-800 dark:text-white">
                  Sign Out
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Log out of your account
                </p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleLogout}
              className="px-4 py-2 bg-red-500 text-white rounded-lg font-medium text-sm"
            >
              Logout
            </motion.button>
          </div>
        </motion.div>
      </div>
    </PageLayout>
  );
}
