import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AdminProvider } from './context/AdminContext';
import Header from './components/Header';
import HapticArcMenu from './components/HapticArcMenu';
import Home from './pages/Home';
import Books from './pages/Books';
import Videos from './pages/Videos';
import Images from './pages/Images';
import Dictionary from './pages/Dictionary';
import Courses from './pages/Courses';
import CourseDetail from './pages/CourseDetail';
import Upload from './pages/Upload';
import Profile from './pages/Profile';
import Search from './pages/Search';
import Request from './pages/Request';
import Admin from './pages/Admin';

function AppContent() {
  const [, setSearchState] = useState({ query: '', filter: 'all' });

  const handleSearch = (query: string, filter: string) => {
    setSearchState({ query, filter });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-teal-50/30 to-blue-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
        <div className="absolute top-0 -left-40 w-80 h-80 bg-teal-400/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-0 left-1/3 w-72 h-72 bg-purple-400/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <Header onSearch={handleSearch} />
      
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/books" element={<Books />} />
          <Route path="/videos" element={<Videos />} />
          <Route path="/images" element={<Images />} />
          <Route path="/dictionary" element={<Dictionary />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/courses/:id" element={<CourseDetail />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/search" element={<Search />} />
          <Route path="/request" element={<Request />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>

      <HapticArcMenu />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AdminProvider>
          <AppContent />
        </AdminProvider>
      </AuthProvider>
    </Router>
  );
}
