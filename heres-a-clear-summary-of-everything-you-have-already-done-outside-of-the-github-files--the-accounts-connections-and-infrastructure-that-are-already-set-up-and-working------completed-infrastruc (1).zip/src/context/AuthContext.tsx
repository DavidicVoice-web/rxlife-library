import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Profile } from '../types';
import { auth } from '../services/api';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, username: string, academicLevel: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUser = async () => {
    try {
      const token = localStorage.getItem('rxlife_token');
      if (!token) {
        setUser(null);
        setProfile(null);
        return;
      }

      const data = await auth.getUser();
      setUser(data.user);
      setProfile(data.profile);
    } catch (error) {
      console.error('Failed to refresh user:', error);
      localStorage.removeItem('rxlife_token');
      setUser(null);
      setProfile(null);
    }
  };

  useEffect(() => {
    refreshUser().finally(() => setIsLoading(false));
  }, []);

  const login = async (email: string, password: string) => {
    const data = await auth.login({ email, password });
    localStorage.setItem('rxlife_token', data.token);
    await refreshUser();
  };

  const signup = async (email: string, password: string, username: string, academicLevel: string) => {
    await auth.signup({ email, password, username, academic_level: academicLevel });
  };

  const logout = async () => {
    try {
      await auth.logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
    localStorage.removeItem('rxlife_token');
    setUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isLoading,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
