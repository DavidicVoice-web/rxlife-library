import { createContext, useContext, useState, ReactNode } from 'react';

interface AdminContextType {
  isAdminAuthenticated: boolean;
  adminLogin: (password: string) => void;
  adminLogout: () => void;
}

const AdminContext = createContext<AdminContextType | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    return localStorage.getItem('rxlife_admin') === 'true';
  });

  const adminLogin = (password: string) => {
    localStorage.setItem('rxlife_admin', 'true');
    localStorage.setItem('rxlife_admin_password', password);
    setIsAdminAuthenticated(true);
  };

  const adminLogout = () => {
    localStorage.removeItem('rxlife_admin');
    localStorage.removeItem('rxlife_admin_password');
    setIsAdminAuthenticated(false);
  };

  return (
    <AdminContext.Provider value={{ isAdminAuthenticated, adminLogin, adminLogout }}>
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
}
