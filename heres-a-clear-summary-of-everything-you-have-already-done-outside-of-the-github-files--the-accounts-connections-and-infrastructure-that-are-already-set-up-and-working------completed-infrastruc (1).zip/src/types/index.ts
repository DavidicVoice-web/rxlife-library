// Database types matching Supabase schema
export interface Book {
  id: number;
  title: string;
  author?: string;
  description?: string;
  file_url?: string;
  thumbnail_url?: string;
  created_at: string;
}

export interface Video {
  id: number;
  title: string;
  duration?: string;
  description?: string;
  file_url?: string;
  thumbnail_url?: string;
  created_at: string;
}

export interface Image {
  id: number;
  title: string;
  source?: string;
  description?: string;
  file_url?: string;
  created_at: string;
}

export interface DictionaryTerm {
  id: number;
  term: string;
  definition: string;
}

export interface Course {
  id: number;
  title: string;
  description?: string;
  lessons: string[];
  created_at: string;
}

export interface PendingUpload {
  id: number;
  type: 'book' | 'video' | 'image';
  data: Record<string, any>;
  submitted_by: string;
  status: string;
  created_at: string;
}

export interface UserRequest {
  id: number;
  user_name?: string;
  request_text: string;
  resolved: boolean;
  created_at: string;
}

export interface Profile {
  id: string;
  username: string;
  academic_level?: string;
  created_at: string;
}

export interface UserProgress {
  id: number;
  user_id: string;
  course_id: number;
  completed_lessons: number[];
  updated_at: string;
}

export interface User {
  id: string;
  email: string;
  profile?: Profile;
}

export type ResourceType = 'book' | 'video' | 'image' | 'dictionary' | 'course';
export type FilterType = 'all' | ResourceType;
